'use strict';

const { St } = imports.gi;
const Me = imports.misc.extensionUtils.getCurrentExtension()
const QuickToggles = Me.imports.quickToggle;
const DashBoard = Me.imports.dashBoard;
const PowerMenu = Me.imports.powerMenu;
const MediaControl = Me.imports.mediaControl;
const MessageIndicator = Me.imports.messageIndicator;
const WorkspacesBar = Me.imports.workspacesBar;
const BatteryBar = Me.imports.batteryBar;
const ThemeSwitcher = Me.imports.themeSwitcher;

const Main = imports.ui.main;
const AppMenu = Main.panel.statusArea.appMenu;
const DateMenu = Main.panel.statusArea.dateMenu;
const Activities = Main.panel.statusArea.activities;

function enable(){
    QuickToggles.enable();
    DashBoard.enable();
    PowerMenu.enable();
    MediaControl.enable();
    MessageIndicator.enable();
    WorkspacesBar.enable(0);
    BatteryBar.enable();
    ThemeSwitcher.enable();

    Activities.hide();
}

function disable(){
    QuickToggles.disable();
    DashBoard.disable();
    PowerMenu.disable();
    MediaControl.disable();
    MessageIndicator.disable();
    WorkspacesBar.disable();
    BatteryBar.disable();
    ThemeSwitcher.disable();

    Activities.show();
}
